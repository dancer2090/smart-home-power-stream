export const MQTT_HOST='192.168.1.191'
export const MQTT_PORT='1883'

export const DB_HOST='localhost'
export const DB_PORT='5432'
export const DB_USER='postgres'
export const DB_PASSWORD='postgres'
export const DB_NAME='smart_home'
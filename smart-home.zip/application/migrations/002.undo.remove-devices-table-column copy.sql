ALTER TABLE IF EXISTS devices
DROP COLUMN priority_group;

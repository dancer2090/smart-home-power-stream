DROP EXTENSION IF EXISTS "uuid-ossp";

DROP FUNCTION IF EXISTS update_modified_column

DROP TABLE IF EXISTS devices 

DROP TRIGGER IF EXISTS update_modified_time ON devices

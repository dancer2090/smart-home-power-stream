# MAC Parents
# 192.168.1.129			40:2a:8f:39:ca:26		1	Shanghai High-Flying Electronics  Technology Co., Ltd
# Logger SN - 2799584781

# MAC My Home
# 192.168.1.120			40:2a:8f:39:4a:a0	279*** Upgrade to Pro IPv4 In-App! ***	1	Shanghai High-Flying Electronics  Technology Co., Ltd	279*** Upgrade to Pro IPv4 In-App! ***
# Logger SN - 2799584781

# Inverter IP - use scan program to find it or find it based on MAC address
# ip_address = '192.168.1.120'

# The serial number of wifi logger (not inverter)
# logger_sn = 2799974328


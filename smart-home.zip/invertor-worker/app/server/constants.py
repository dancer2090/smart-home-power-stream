import os
cwd = os.getcwd()

LOGGER_SN = 2799974328
INVERTER_IP = '192.168.1.117'
REGISTERS_FILENAME = 'deye_hybrid.yaml'
REGISTERS_FILENAME_PATH = f'{os.getcwd()}/invertor-worker/app/server/services/deye/'
LOGGER_PORT = 8899

MQTT_HOST = '192.168.1.191'
MQTT_PORT = 1883

# DEYE INVERTER scanning

## Requirements
- Python version 3.11.6 (3.9.0 also works)
- [Pysolarmanv5 lib](https://pysolarmanv5.readthedocs.io/en/stable/)


### Installation
```commandline
pip install -r requirements.txt
```

### Installation
```commandline
python ./app/server/worker.py 
```